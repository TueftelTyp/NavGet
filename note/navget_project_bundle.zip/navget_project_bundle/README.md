# NavGet Project Bundle

## Projektidee
NavGet ist ein kompaktes Motorrad-Navigations-/Bediengerät auf Basis eines ESP32-S3 mit rundem 1,28-Zoll-GC9A01A-Display (240x240 px). Das Smartphone übernimmt Navigation und Datenquellen; NavGet zeigt eine kompakte Fahrer-UI und soll später per BLE verbunden werden.

## Hardware
- ESP32-S3
- Rundes 1.28" Display
- 240x240 px
- GC9A01A
- Geplante 3 physische Tasten

### Bisher verwendete Display-Pins
```cpp
#define TFT_DC    8
#define TFT_CS    9
#define TFT_SCLK  10
#define TFT_MOSI  11
#define TFT_RST   12
#define TFT_MISO  -1
#define TFT_BL    40
```

## UI-Konzept
```text
                         AKKU
                       DISTANZ


      TELEFON          MANOEVER          MUSIK


                     STRASSENNAME
```

Wichtige Regeln:
- Akku oben mittig, nur Symbol
- Distanz direkt darunter
- Manöver möglichst groß in der Mitte
- Telefon links der Mitte
- Musik rechts der Mitte
- Straßenname mittig und möglichst weit unten
- Kein Text wie TURN oder KOMPASS
- Zielrichtungsmodus ist kein Kompass, sondern nur ein großer Richtungspfeil

## Bedienlogik
Geplante 3 Tasten:
- 1 = Turn-by-Turn <-> Zielrichtung
- 2 = Telefon
- 3 = Musik Play/Pause

Serial-Testbefehle:
- n = nächstes Manöver
- i = eingehender Anruf
- o = ausgehender Anruf
- c = Gespräch aktiv
- r = Anruf abgewiesen
- x = kein Anruf / aufgelegt
- a = Zielrichtung links
- d = Zielrichtung rechts
- + = Akku hoch
- - = Akku runter

## Navigation
Turn-by-Turn-Manöver sollen als Bildassets dargestellt werden, nicht mehr per Hand gezeichnet.

Enthaltene Manöver:
- geradeaus
- leicht links
- links
- scharf links
- leicht rechts
- rechts
- scharf rechts
- U-Turn links
- U-Turn rechts
- Kreisverkehr in mehreren Ausfahrtsrichtungen

## Kreisverkehr-Regeln
Ein Kreisel-Symbol soll immer:
- genau einen geschlossenen Kreis
- eine Zufahrt von unten
- genau eine Ausfahrt
- Pfeilspitze nur an dieser Ausfahrt

Keine zusätzlichen Straßenstummel, Verzweigungen, zweiten Ausfahrten oder internen Pfeile.

## Symbol-Stil
- Farbe: #C9F601
- Hintergrund: transparent
- kein Rand
- kein Schatten
- keine Verläufe
- 200x200 px

Das Symbolarchiv liegt unter `assets/navget_symbols_200x200.zip`.

## LVGL / SquareLine
Geplante Screen-Struktur:
```text
Boot
Main
```

Main:
```text
Main
├── Battery
├── Distance
├── Phone
├── NavTurn
├── NavTarget
├── Music
└── Street
```

`NavTurn` und `NavTarget` liegen exakt übereinander.

Turn-by-Turn:
- NavTurn sichtbar
- NavTarget hidden

Zielrichtung:
- NavTurn hidden
- NavTarget sichtbar

## Bootscreen
Der Bootscreen ist bereits erstellt und soll nur einmal beim Start gezeigt werden. Danach wird auf Main gewechselt und der Bootscreen nicht mehr geladen.

## Spätere Architektur
Geplante Zustände:
- nav_mode
- maneuver
- distance
- street
- target_angle
- music_playing
- call_state
- battery_level

Das Smartphone soll diese Zustände später per BLE an den ESP32 senden.

## Nächste Schritte
1. SquareLine-Main-Screen fertig bauen
2. Symbole als Assets importieren
3. NavTurn / NavTarget übereinanderlegen
4. SquareLine exportieren
5. vollständigen ESP32-S3 + GC9A01A + LVGL Sketch erstellen
6. UI zunächst per Serial testen
7. BLE anbinden
8. echte Taster anbinden

## Wichtige Präferenz
Bei Firmware-Änderungen bitte immer den vollständigen `.ino`-Code ausgeben, keine Diff-Schnipsel.
