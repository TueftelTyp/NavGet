# UI State Model

Geplante Zustandswerte:

```text
nav_mode
maneuver
distance
street
target_angle
music_playing
call_state
battery_level
```

Beispielhafte LVGL-Aktualisierung:

```cpp
lv_label_set_text(ui_Distance, "350 m");
lv_label_set_text(ui_Street, "Musterstrasse");
lv_image_set_src(ui_NavTurn, &img_turn_right);
lv_image_set_rotation(ui_NavTarget, angle * 10);
```

Turn-Modus:
```cpp
lv_obj_clear_flag(ui_NavTurn, LV_OBJ_FLAG_HIDDEN);
lv_obj_add_flag(ui_NavTarget, LV_OBJ_FLAG_HIDDEN);
```

Zielmodus:
```cpp
lv_obj_add_flag(ui_NavTurn, LV_OBJ_FLAG_HIDDEN);
lv_obj_clear_flag(ui_NavTarget, LV_OBJ_FLAG_HIDDEN);
```
