# SquareLine Layout

Empfohlene Ausgangspositionen für 240x240 px:

- Battery: X ~ 105, Y ~ 7
- Distance: X ~ 70, Y ~ 28, W ~ 100, H ~ 30
- NavTurn / NavTarget: X ~ 60-70, Y ~ 60-65, W ~ 110-120, H ~ 110-125
- Phone: X ~ 15-20, Y ~ 105, W ~ 35, H ~ 35
- Music: X ~ 188-190, Y ~ 105, W ~ 35, H ~ 35
- Street: X ~ 30, Y ~ 198, W ~ 180, H ~ 25

Empfohlene Objektnamen:
- ui_Battery
- ui_Distance
- ui_Phone
- ui_NavTurn
- ui_NavTarget
- ui_Music
- ui_Street
