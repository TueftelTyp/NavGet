NavGet Symbolpaket - mehrere Auflösungen

Enthaltene Größen:
- 30x30
- 40x40
- 50x50
- 60x60
- 70x70
- 80x80
- 90x90
- 100x100

Eigenschaften:
- PNG
- transparenter Hintergrund
- einfarbig #C9F601
- gleiche Dateinamen in allen Größenordnern

Empfehlung:
- Für sehr kleine UI-Elemente: 30x30 oder 40x40
- Für normale Symbole auf kleinen Displays: 50x50 bis 70x70
- Für größere Hauptelemente: 80x80 bis 100x100
