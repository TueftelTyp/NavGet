NavGet route symbols

Format: PNG, 200x200 px, transparent background
Color: #C9F601 only

Included:
- straight
- slight left / left / sharp left
- slight right / right / sharp right
- U-turn left / right
- roundabout exits: right, upper-right, straight, upper-left, left, lower-left, lower-right, U-turn
