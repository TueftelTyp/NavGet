NavGet Symbol Pack - 30x30 bis 100x100

Enthalten:
- 17 Routen-/Kreiselsymbole in 30, 40, 50, 60, 70, 80, 90 und 100 px
- 1 Kompass-/Richtungspfeil mit nur einer Spitze in denselben Größen

Eigenschaften:
- PNG
- transparenter Hintergrund
- einfarbig #C9F601

Ordner:
route_symbols/<Groesse>/...
compass_arrow/<Groesse>/compass_direction_arrow.png
