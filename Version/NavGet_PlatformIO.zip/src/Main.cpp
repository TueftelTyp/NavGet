#include <lvgl.h>
#include <Adafruit_GFX.h>
#include <Adafruit_GC9A01A.h>
#include "ui.h"
#include "images.h"

extern objects_t objects;

// ============================================================
// DISPLAY PINS
// ============================================================
#define TFT_DC      8
#define TFT_CS      9
#define TFT_SCLK    10
#define TFT_MOSI    11
#define TFT_RST     12
#define TFT_MISO    -1
#define TFT_BL      40

#define MY_DISP_HOR_RES 240
#define MY_DISP_VER_RES 240

Adafruit_GC9A01A tft(TFT_CS, TFT_DC, TFT_MOSI, TFT_SCLK, TFT_RST, TFT_MISO);

// ============================================================
// PARTIAL BUFFER (schneller als Full-Screen)
// 240 * 40 * 2 Bytes = 19.200 Bytes
// ============================================================
static lv_color_t buf[MY_DISP_HOR_RES * 40];

// ============================================================
// FORWARD DECLARATIONS
// ============================================================
void print_help();
void handleSerialCommands();

// ============================================================
// HELLIGKEIT (PWM)
// ============================================================
#define PWM_CHANNEL   0
#define PWM_FREQ      5000
#define PWM_RES_BITS  8

int current_brightness = 100;

void set_brightness(int percent) {
    if (percent < 0) percent = 0;
    if (percent > 100) percent = 100;
    current_brightness = percent;
    uint8_t duty = map(percent, 0, 100, 0, 255);
    ledcWrite(PWM_CHANNEL, duty);
    Serial.printf("Helligkeit: %d%% (PWM=%d)\n", percent, duty);
}

// ============================================================
// ZUSTANDS-MANAGEMENT
// ============================================================
enum UiState { STATE_NAV_TURN = 0, STATE_NAV_SPEED = 1, STATE_NAV_TARGET = 2 };
UiState current_state = STATE_NAV_TURN;

const lv_image_dsc_t* maneuver_images[] = {
    &img_01_straight, &img_02_slight_left, &img_03_left, &img_04_sharp_left,
    &img_05_slight_right, &img_06_right, &img_07_sharp_right, &img_08_u_turn_left,
    &img_09_u_turn_right, &img_10_roundabout_right, &img_11_roundabout_upper_right,
    &img_12_roundabout_straight, &img_13_roundabout_upper_left, &img_14_roundabout_left,
    &img_15_roundabout_lower_left, &img_16_roundabout_lower_right, &img_17_roundabout_u_turn
};
int current_maneuver_index = 0;
bool music_playing = false;

void set_ui_state(UiState state) {
    current_state = state;
    
    lv_obj_add_flag(objects.direction, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(objects.distance, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(objects.distance_entity, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(objects.street, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(objects.speed_entity, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(objects.speed_num, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(objects.navi, LV_OBJ_FLAG_HIDDEN);

    switch (state) {
        case STATE_NAV_TURN:
            lv_obj_clear_flag(objects.direction, LV_OBJ_FLAG_HIDDEN);
            lv_obj_clear_flag(objects.distance, LV_OBJ_FLAG_HIDDEN);
            lv_obj_clear_flag(objects.distance_entity, LV_OBJ_FLAG_HIDDEN);
            lv_obj_clear_flag(objects.street, LV_OBJ_FLAG_HIDDEN);
            break;
        case STATE_NAV_SPEED:
            lv_obj_clear_flag(objects.speed_entity, LV_OBJ_FLAG_HIDDEN);
            lv_obj_clear_flag(objects.speed_num, LV_OBJ_FLAG_HIDDEN);
            break;
        case STATE_NAV_TARGET:
            lv_obj_clear_flag(objects.navi, LV_OBJ_FLAG_HIDDEN);
            break;
    }
    
    lv_obj_invalidate(lv_scr_act());
    lv_refr_now(NULL);
}

// ============================================================
// DISPLAY FLUSH
// ============================================================
void my_disp_flush(lv_display_t *disp, const lv_area_t *area, uint8_t *px_map) {
    uint32_t w = (area->x2 - area->x1 + 1);
    uint32_t h = (area->y2 - area->y1 + 1);
    tft.startWrite();
    tft.setAddrWindow(area->x1, area->y1, w, h);
    tft.writePixels((uint16_t *)px_map, w * h, true);
    tft.endWrite();
    lv_display_flush_ready(disp);
}

void boot_to_main_timer_cb(lv_timer_t * timer) {
    Serial.println("→ Timer abgelaufen, wechsle zu Main Screen");
    lv_screen_load_anim(objects.main, LV_SCR_LOAD_ANIM_NONE, 0, 0, false);
    set_ui_state(current_state);
    lv_timer_del(timer);
}

// ============================================================
// HILFE
// ============================================================
void print_help() {
    Serial.println("\n=== BEFEHLSÜBERSICHT ===");
    Serial.println("MODI:");
    Serial.println("  t = NavTurn   |  s = NavSpeed  |  v = NavTarget");
    Serial.println("\nMANÖVER (nur NavTurn):");
    Serial.println("  0-9, a-g = Manöver 1-17");
    Serial.println("\nGESCHWINDIGKEIT:");
    Serial.println("  U = Speed +10  |  D = Speed -10");
    Serial.println("\nAKKU:  + / -");
    Serial.println("\nTELEFON:");
    Serial.println("  i = Incoming | o = Outgoing | k = Ended | x = Aus");
    Serial.println("\nMUSIK:  m = Play/Pause Toggle");
    Serial.println("\nHELLIGKEIT:  H0-H9 = 0-90% | H10 = 100% | h = Anzeige");
    Serial.println("\nROTATION (nur NavTarget):  r = +45° | R = Reset");
    Serial.println("========================\n");
}

// ============================================================
// SETUP
// ============================================================
void setup() {
    Serial.begin(115200);
    Serial.println("=== NAVGET SYSTEM START ===");
    
    tft.begin();
    tft.setRotation(0);
    
    // SPI-Geschwindigkeit erhöhen (80 MHz)
    tft.setSPISpeed(80000000);
    
    ledcSetup(PWM_CHANNEL, PWM_FREQ, PWM_RES_BITS);
    ledcAttachPin(TFT_BL, PWM_CHANNEL);
    set_brightness(100);
    
    tft.fillScreen(0x0000);

    lv_init();
    lv_display_t *disp = lv_display_create(MY_DISP_HOR_RES, MY_DISP_VER_RES);
    lv_display_set_flush_cb(disp, my_disp_flush);
    // PARTIAL MODE mit kleinerem Buffer für schnellere Updates
    lv_display_set_buffers(disp, buf, NULL, sizeof(buf), LV_DISPLAY_RENDER_MODE_PARTIAL);

    create_screens();

    lv_screen_load_anim(objects.boot, LV_SCR_LOAD_ANIM_NONE, 0, 0, false);
    // === POSITIONEN UND GRÖSSEN ANPASSEN ===
    // distance und distance_entity zentrieren
    lv_obj_set_pos(objects.distance, -13, 30);           // x=0 = zentriert (bei ALIGN_TOP_MID)
    lv_obj_set_pos(objects.distance_entity, 121, 30);    // gleiche y-Position
    //lv_obj_set_align(objects.distance_entity, LV_ALIGN_TOP_MID);
    
    // street an die Rundung anpassen
    //lv_obj_set_width(objects.street, 180);             // schmaler machen (passt in die Rundung)
    lv_obj_set_pos(objects.street, 0, -17);            // weiter nach oben (mehr Platz)
    lv_label_set_long_mode(objects.street, LV_LABEL_LONG_SCROLL_CIRCULAR);  // endloses Scrollen
    
    // Skalierung der Symbole
    lv_image_set_scale(objects.navi, 500);
    lv_image_set_scale(objects.direction, 600);
    lv_image_set_scale(objects.call, 100);
    lv_image_set_scale(objects.playpause, 100);
    
    // ==========================================
    Serial.println("→ Boot-Screen geladen (mit Spinner), warte 3 Sekunden...");
    lv_timer_create(boot_to_main_timer_cb, 3000, NULL);

    lv_label_set_text(objects.street, "Hauptstrasse");
    lv_label_set_text(objects.distance, "250");
    lv_label_set_text(objects.distance_entity, "m");
    lv_label_set_text(objects.speed_num, "0");
    lv_label_set_text(objects.speed_entity, "km/h");
    lv_bar_set_value(objects.batterylevel, 100, LV_ANIM_OFF);
    lv_arc_set_range(objects.arc, 0, 100);
    lv_arc_set_value(objects.arc, 0);

    lv_obj_add_flag(objects.call, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(objects.playpause, LV_OBJ_FLAG_HIDDEN);

    Serial.println("System bereit.");
    print_help();
}

// ============================================================
// LOOP - OPTIMIERT FÜR MAXIMALE FLÜSSIGKEIT
// ============================================================
void loop() {
    // 1ms Tick für flüssige Animationen
    lv_tick_inc(1);
    
    // LVGL Timer Handler (animiert den Spinner)
    lv_timer_handler();
    
    // EEZ UI Tick
    ui_tick();
    
    // Serial Commands verarbeiten
    if (Serial.available()) {
        handleSerialCommands();
    }
    
    // CPU an andere Tasks abgeben, aber nicht warten
    delay(0);
}

// ============================================================
// SERIAL HANDLER
// ============================================================
void handleSerialCommands() {
    String input = Serial.readStringUntil('\n');
    input.trim();
    if (input.length() == 0) return;
    
    char cmd = input.charAt(0);
    
    switch (cmd) {
        case 't':
            Serial.println("→ NavTurn");
            set_ui_state(STATE_NAV_TURN);
            break;
        case 's':
            Serial.println("→ NavSpeed");
            set_ui_state(STATE_NAV_SPEED);
            break;
        case 'v':
            Serial.println("→ NavTarget");
            set_ui_state(STATE_NAV_TARGET);
            break;

        case '0': case '1': case '2': case '3': case '4':
        case '5': case '6': case '7': case '8': case '9':
        case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g': {
            int idx = 0;
            if (cmd >= '0' && cmd <= '9') idx = cmd - '0';
            else idx = 10 + (cmd - 'a');
            if (idx < 17) {
                current_maneuver_index = idx;
                lv_image_set_src(objects.direction, maneuver_images[idx]);
                Serial.printf("→ Manöver %d gesetzt\n", idx + 1);
            }
            break;
        }

        case 'U': {
            int32_t cur = lv_arc_get_value(objects.arc);
            if (cur < 100) {
                lv_arc_set_value(objects.arc, cur + 10);
                char buf[8]; snprintf(buf, sizeof(buf), "%d", cur + 10);
                lv_label_set_text(objects.speed_num, buf);
                Serial.printf("→ Speed: %d\n", cur + 10);
            }
            break;
        }
        case 'D': {
            int32_t cur = lv_arc_get_value(objects.arc);
            if (cur > 0) {
                lv_arc_set_value(objects.arc, cur - 10);
                char buf[8]; snprintf(buf, sizeof(buf), "%d", cur - 10);
                lv_label_set_text(objects.speed_num, buf);
                Serial.printf("→ Speed: %d\n", cur - 10);
            }
            break;
        }

        case '+': {
            int32_t batt = lv_bar_get_value(objects.batterylevel);
            if (batt < 100) {
                lv_bar_set_value(objects.batterylevel, batt + 10, LV_ANIM_ON);
                Serial.printf("→ Akku: %d%%\n", batt + 10);
            }
            break;
        }
        case '-': {
            int32_t batt = lv_bar_get_value(objects.batterylevel);
            if (batt > 0) {
                lv_bar_set_value(objects.batterylevel, batt - 10, LV_ANIM_ON);
                Serial.printf("→ Akku: %d%%\n", batt - 10);
            }
            break;
        }

        case 'i':
            lv_image_set_src(objects.call, &img_incoming);
            lv_obj_clear_flag(objects.call, LV_OBJ_FLAG_HIDDEN);
            Serial.println("→ Phone: Incoming");
            break;
        case 'o':
            lv_image_set_src(objects.call, &img_outgoing);
            lv_obj_clear_flag(objects.call, LV_OBJ_FLAG_HIDDEN);
            Serial.println("→ Phone: Outgoing");
            break;
        case 'k':
            lv_image_set_src(objects.call, &img_ended);
            lv_obj_clear_flag(objects.call, LV_OBJ_FLAG_HIDDEN);
            Serial.println("→ Phone: Ended");
            break;
        case 'x':
            lv_obj_add_flag(objects.call, LV_OBJ_FLAG_HIDDEN);
            Serial.println("→ Phone: Aus");
            break;

        case 'm':
            music_playing = !music_playing;
            lv_image_set_src(objects.playpause, music_playing ? &img_play : &img_pause);
            lv_obj_clear_flag(objects.playpause, LV_OBJ_FLAG_HIDDEN);
            Serial.printf("→ Musik: %s\n", music_playing ? "PLAY" : "PAUSE");
            break;

        case 'H': {
            int val = input.substring(1).toInt();
            set_brightness(val);
            break;
        }
        case 'h':
            Serial.printf("→ Aktuelle Helligkeit: %d%%\n", current_brightness);
            break;

        case 'r': {
            static int rotation = 0;
            rotation = (rotation + 450) % 3600;
            lv_image_set_rotation(objects.navi, rotation);
            Serial.printf("→ Navi Rotation: %d°\n", rotation / 10);
            break;
        }
        case 'R':
            lv_image_set_rotation(objects.navi, 0);
            Serial.println("→ Navi Rotation reset");
            break;

        case '?':
            print_help();
            break;

        default:
            Serial.printf("Unbekannter Befehl: '%s' (Tippe '?' für Hilfe)\n", input.c_str());
            break;
    }
}