#include <lvgl.h>
#include <Adafruit_GFX.h>
#include <Adafruit_GC9A01A.h>
#include "ui.h"
#include "images.h"

extern objects_t objects;

// ============================================================
// DISPLAY PINS
// ============================================================
#define TFT_DC    8
#define TFT_CS    9
#define TFT_SCLK  10
#define TFT_MOSI  11
#define TFT_RST   12
#define TFT_MISO  -1
#define TFT_BL    40

#define MY_DISP_HOR_RES 240
#define MY_DISP_VER_RES 240

Adafruit_GC9A01A tft(TFT_CS, TFT_DC, TFT_MOSI, TFT_SCLK, TFT_RST, TFT_MISO);

// Buffer für flüssiges Rendering
static lv_color_t buf[MY_DISP_HOR_RES * 80];

// ============================================================
// ZUSTANDS-MANAGEMENT
// ============================================================
enum UiState { STATE_NAV_TARGET = 0, STATE_NAV_TURN = 1, STATE_NAV_SPEED = 2 };
UiState current_state = STATE_NAV_TURN;

// Manöver-Bilder (17 Stück)
const lv_image_dsc_t* maneuver_images[] = {
    &img_01_straight, &img_02_slight_left, &img_03_left, &img_04_sharp_left,
    &img_05_slight_right, &img_06_right, &img_07_sharp_right, &img_08_u_turn_left,
    &img_09_u_turn_right, &img_10_roundabout_right, &img_11_roundabout_upper_right,
    &img_12_roundabout_straight, &img_13_roundabout_upper_left, &img_14_roundabout_left,
    &img_15_roundabout_lower_left, &img_16_roundabout_lower_right, &img_17_roundabout_u_turn
};
int current_maneuver_index = 0;
bool music_playing = false;

void set_ui_state(UiState state) {
    current_state = state;

    // 1. ALLE modusspezifischen Objekte erst einmal ausblenden
    lv_obj_add_flag(objects.navi, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(objects.direction, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(objects.distance, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(objects.distance_entity, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(objects.street, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(objects.arc, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(objects.speed_entity, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(objects.speed_num, LV_OBJ_FLAG_HIDDEN);

    // 2. Nur die Objekte des gewünschten Modus einblenden
    switch (state) {
        case STATE_NAV_TARGET:
            lv_obj_clear_flag(objects.navi, LV_OBJ_FLAG_HIDDEN);
            lv_obj_clear_flag(objects.arc, LV_OBJ_FLAG_HIDDEN);
            break;
            
        case STATE_NAV_TURN:
            lv_obj_clear_flag(objects.direction, LV_OBJ_FLAG_HIDDEN);
            lv_obj_clear_flag(objects.distance, LV_OBJ_FLAG_HIDDEN);
            lv_obj_clear_flag(objects.distance_entity, LV_OBJ_FLAG_HIDDEN);
            lv_obj_clear_flag(objects.street, LV_OBJ_FLAG_HIDDEN);
            lv_obj_clear_flag(objects.arc, LV_OBJ_FLAG_HIDDEN);
            break;
            
        case STATE_NAV_SPEED:
            lv_obj_clear_flag(objects.arc, LV_OBJ_FLAG_HIDDEN);
            lv_obj_clear_flag(objects.speed_entity, LV_OBJ_FLAG_HIDDEN);
            lv_obj_clear_flag(objects.speed_num, LV_OBJ_FLAG_HIDDEN);
            break;
    }
}

// ============================================================
// LVGL & DISPLAY SETUP
// ============================================================
void my_disp_flush(lv_display_t *disp, const lv_area_t *area, uint8_t *px_map) {
    uint32_t w = (area->x2 - area->x1 + 1);
    uint32_t h = (area->y2 - area->y1 + 1);
    tft.startWrite();
    tft.setAddrWindow(area->x1, area->y1, w, h);
    tft.writePixels((uint16_t *)px_map, w * h, true);
    tft.endWrite();
    lv_display_flush_ready(disp);
}

void boot_to_main_timer_cb(lv_timer_t * timer) {
    loadScreen(SCREEN_ID_MAIN); 
    set_ui_state(current_state);
    lv_timer_del(timer);
}

void setup() {
    Serial.begin(115200);
    
    tft.begin();
    tft.setRotation(0);
    pinMode(TFT_BL, OUTPUT);
    digitalWrite(TFT_BL, HIGH);
    tft.fillScreen(0x0000);

    lv_init();
    lv_display_t *disp = lv_display_create(MY_DISP_HOR_RES, MY_DISP_VER_RES);
    lv_display_set_flush_cb(disp, my_disp_flush);
    lv_display_set_buffers(disp, buf, NULL, sizeof(buf), LV_DISPLAY_RENDER_MODE_PARTIAL);

    create_screens();
    loadScreen(SCREEN_ID_BOOT);
    lv_timer_create(boot_to_main_timer_cb, 3000, NULL);

    // Startwerte setzen
    lv_label_set_text(objects.street, "Hauptstrasse");
    lv_label_set_text(objects.distance, "250");
    lv_label_set_text(objects.distance_entity, "m");
    lv_label_set_text(objects.speed_num, "0");
    lv_label_set_text(objects.speed_entity, "km/h");
    lv_bar_set_value(objects.batterylevel, 100, LV_ANIM_OFF);
    lv_arc_set_range(objects.arc, 0, 100); // Speed Max Default
    lv_arc_set_value(objects.arc, 0);

    // Initial ausblenden
    lv_obj_add_flag(objects.playpause, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(objects.call, LV_OBJ_FLAG_HIDDEN);

    Serial.println("NavGet Ready.");
    Serial.println("Modi: 't'=Target, 'u'=Turn, 's'=Speed");
    Serial.println("Werte: 'n'=Naechstes, '+'/'-'=Akku, 'r'=Rotation");
}

void loop() {
    lv_tick_inc(5);
    lv_timer_handler();
    ui_tick(); 
    delay(5);
    
    if (Serial.available()) {
        char cmd = Serial.read();
        switch (cmd) {
            // --- MODUS WECHSEL ---
            case 't': set_ui_state(STATE_NAV_TARGET); break;
            case 'u': set_ui_state(STATE_NAV_TURN); break;
            case 's': set_ui_state(STATE_NAV_SPEED); break;

            // --- NAVIGATION ---
            case 'n': 
                current_maneuver_index = (current_maneuver_index + 1) % 17;
                lv_image_set_src(objects.direction, maneuver_images[current_maneuver_index]);
                lv_label_set_text(objects.distance, "150");
                break;
            case 'r': {
                static int rotation = 0;
                rotation = (rotation + 450) % 3600; // 45 Grad
                lv_image_set_rotation(objects.navi, rotation);
                break;
            }

            // --- TELEFON & MUSIK ---
            case 'i': lv_image_set_src(objects.call, &img_incoming); lv_obj_clear_flag(objects.call, LV_OBJ_FLAG_HIDDEN); break;
            case 'x': lv_obj_add_flag(objects.call, LV_OBJ_FLAG_HIDDEN); break;
            case 'm': 
                music_playing = !music_playing;
                lv_image_set_src(objects.playpause, music_playing ? &img_play : &img_pause);
                if(music_playing) lv_obj_clear_flag(objects.playpause, LV_OBJ_FLAG_HIDDEN);
                break;

            // --- AKKU & SPEED (Simulation) ---
            case '+': {
                int32_t batt = lv_bar_get_value(objects.batterylevel);
                if (batt < 100) lv_bar_set_value(objects.batterylevel, batt + 10, LV_ANIM_ON);
                break;
            }
            case '-': {
                int32_t batt = lv_bar_get_value(objects.batterylevel);
                if (batt > 0) lv_bar_set_value(objects.batterylevel, batt - 10, LV_ANIM_ON);
                break;
            }
        }
    }
}