#include <lvgl.h>
#include <Adafruit_GFX.h>
#include <Adafruit_GC9A01A.h>
#include "ui.h"
#include "images.h"

extern objects_t objects;

// ============================================================
// DISPLAY PINS
// ============================================================
#define TFT_DC    8
#define TFT_CS    9
#define TFT_SCLK  10
#define TFT_MOSI  11
#define TFT_RST   12
#define TFT_MISO  -1
#define TFT_BL    40

#define MY_DISP_HOR_RES 240
#define MY_DISP_VER_RES 240

Adafruit_GC9A01A tft(TFT_CS, TFT_DC, TFT_MOSI, TFT_SCLK, TFT_RST, TFT_MISO);

// OPTIMIERTER BUFFER: 80 Zeilen statt Full-Screen. 
// Spart massiv RAM (nur ~38 KB), verhindert aber trotzdem sichtbares Teearing.
static lv_color_t buf[MY_DISP_HOR_RES * 80];

// ============================================================
// ZUSTANDS-MANAGEMENT
// ============================================================
enum UiState {
    STATE_NAV_TARGET = 0,
    STATE_NAV_TURN = 1,
    STATE_NAV_SPEED = 2
};

UiState current_state = STATE_NAV_TURN;

const lv_image_dsc_t* maneuver_images[] = {
    &img_01_straight, &img_02_slight_left, &img_03_left, &img_04_sharp_left,
    &img_05_slight_right, &img_06_right, &img_07_sharp_right, &img_08_u_turn_left,
    &img_09_u_turn_right, &img_10_roundabout_right, &img_11_roundabout_upper_right,
    &img_12_roundabout_straight, &img_13_roundabout_upper_left, &img_14_roundabout_left,
    &img_15_roundabout_lower_left, &img_16_roundabout_lower_right, &img_17_roundabout_u_turn
};
int current_maneuver_index = 0;
bool music_playing = false;

void set_ui_state(UiState state) {
    current_state = state;

    // Alle zustandsspezifischen Parents ausblenden
    lv_obj_add_flag(objects.nav_target, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(objects.nav_turn, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(objects.arc_speed, LV_OBJ_FLAG_HIDDEN);

    // Gewünschten Parent einblenden (Kinder werden automatisch mit eingeblendet)
    switch (state) {
        case STATE_NAV_TARGET:
            lv_obj_clear_flag(objects.nav_target, LV_OBJ_FLAG_HIDDEN);
            break;
        case STATE_NAV_TURN:
            lv_obj_clear_flag(objects.nav_turn, LV_OBJ_FLAG_HIDDEN);
            break;
        case STATE_NAV_SPEED:
            lv_obj_clear_flag(objects.arc_speed, LV_OBJ_FLAG_HIDDEN);
            break;
    }
}

// ============================================================
// LVGL & DISPLAY SETUP
// ============================================================
void my_disp_flush(lv_display_t *disp, const lv_area_t *area, uint8_t *px_map) {
    uint32_t w = (area->x2 - area->x1 + 1);
    uint32_t h = (area->y2 - area->y1 + 1);

    tft.startWrite();
    tft.setAddrWindow(area->x1, area->y1, w, h);
    tft.writePixels((uint16_t *)px_map, w * h, true);
    tft.endWrite();

    lv_display_flush_ready(disp);
}

void boot_to_main_timer_cb(lv_timer_t * timer) {
    loadScreen(SCREEN_ID_MAIN); 
    set_ui_state(current_state);
    lv_timer_del(timer);
}

void setup() {
    Serial.begin(115200);
    Serial.println("NavGet Boot...");

    tft.begin();
    tft.setRotation(0);
    
    pinMode(TFT_BL, OUTPUT);
    digitalWrite(TFT_BL, HIGH);
    tft.fillScreen(0x0000);

    lv_init();

    lv_display_t *disp = lv_display_create(MY_DISP_HOR_RES, MY_DISP_VER_RES);
    lv_display_set_flush_cb(disp, my_disp_flush);
    // PARTIAL MODE mit optimiertem Buffer für beste Performance/RAM-Balance
    lv_display_set_buffers(disp, buf, NULL, sizeof(buf), LV_DISPLAY_RENDER_MODE_PARTIAL);

    create_screens();
    loadScreen(SCREEN_ID_BOOT);
    lv_timer_create(boot_to_main_timer_cb, 3000, NULL);

    // Startwerte
    lv_label_set_text(objects.street, "Hauptstrasse");
    lv_label_set_text(objects.distance, "250");
    lv_label_set_text(objects.distance_entity, "m");
    lv_label_set_text(objects.lbl_speed, "0");
    lv_label_set_text(objects.lbl_speed_entity, "km/h");
    lv_bar_set_value(objects.battery, 100, LV_ANIM_OFF);

    lv_obj_add_flag(objects.phone, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(objects.music, LV_OBJ_FLAG_HIDDEN);

    Serial.println("NavGet Ready.");
    Serial.println("Zustand: 't'=Target, 'u'=Turn, 's'=Speed");
    Serial.println("Manoever: 'n'=Naechstes, 'r'=Rotiere Target");
    Serial.println("Phone: 'i'=Incoming, 'x'=Aus | Musik: 'm'=Toggle");
    Serial.println("Akku: '+'/-'");
}

void loop() {
    lv_tick_inc(5);
    lv_timer_handler();
    ui_tick(); 
    delay(5);
    handleSerialCommands();
}

// ============================================================
// SERIAL PARSER
// ============================================================
void handleSerialCommands() {
    if (Serial.available()) {
        char cmd = Serial.read();
        
        switch (cmd) {
            case 't':
                Serial.println("Cmd: Zustand -> NavTarget");
                set_ui_state(STATE_NAV_TARGET);
                break;
            case 'u':
                Serial.println("Cmd: Zustand -> NavTurn");
                set_ui_state(STATE_NAV_TURN);
                break;
            case 's':
                Serial.println("Cmd: Zustand -> NavSpeed");
                set_ui_state(STATE_NAV_SPEED);
                break;

            case 'n': {
                Serial.println("Cmd: Naechstes Manoever");
                current_maneuver_index = (current_maneuver_index + 1) % 17;
                lv_image_set_src(objects.nav_turn, maneuver_images[current_maneuver_index]);
                lv_label_set_text(objects.distance, "150");
                break;
            }

            case 'i':
                Serial.println("Cmd: Eingehender Anruf");
                lv_image_set_src(objects.phone, &img_incoming);
                lv_obj_clear_flag(objects.phone, LV_OBJ_FLAG_HIDDEN);
                break;
            case 'x':
                Serial.println("Cmd: Aufgelegt");
                lv_obj_add_flag(objects.phone, LV_OBJ_FLAG_HIDDEN);
                break;

            case 'm':
                Serial.println("Cmd: Musik Toggle");
                music_playing = !music_playing;
                if (music_playing) {
                    lv_image_set_src(objects.music, &img_play);
                    lv_obj_clear_flag(objects.music, LV_OBJ_FLAG_HIDDEN);
                } else {
                    lv_image_set_src(objects.music, &img_pause);
                }
                break;

            case 'r': {
                Serial.println("Cmd: Rotiere NavTarget");
                static int rotation = 0;
                rotation += 450; // 45 Grad Schritte (in 0.1 Grad)
                if (rotation >= 3600) rotation = 0;
                lv_image_set_rotation(objects.nav_target, rotation);
                break;
            }

            case '+': {
                Serial.println("Cmd: Akku +10%");
                int32_t batt = lv_bar_get_value(objects.battery);
                if (batt < 100) lv_bar_set_value(objects.battery, batt + 10, LV_ANIM_ON);
                break;
            }
            case '-': {
                Serial.println("Cmd: Akku -10%");
                int32_t batt = lv_bar_get_value(objects.battery);
                if (batt > 0) lv_bar_set_value(objects.battery, batt - 10, LV_ANIM_ON);
                break;
            }
        }
    }
}