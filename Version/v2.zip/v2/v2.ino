#include <lvgl.h>
#include <Adafruit_GFX.h>
#include <Adafruit_GC9A01A.h>
#include "ui.h"

// Zugriff auf die in screens.h definierten UI-Objekte
extern objects_t objects;

// ============================================================
// DISPLAY PINS
// ============================================================
#define TFT_DC    8
#define TFT_CS    9
#define TFT_SCLK  10
#define TFT_MOSI  11
#define TFT_RST   12
#define TFT_MISO  -1
#define TFT_BL    40

#define MY_DISP_HOR_RES 240
#define MY_DISP_VER_RES 240

// Adafruit Display-Objekt initialisieren
Adafruit_GC9A01A tft(TFT_CS, TFT_DC, TFT_MOSI, TFT_SCLK, TFT_RST, TFT_MISO);

// GRÖSSERER BUFFER: Verhindert das "stückweise" Aufbauen (Teearing)
// 240 * 80 Pixel * 2 Bytes = ~38 KB (Der ESP32-S3 hat 512 KB RAM, das ist absolut sicher)
static lv_color_t buf[MY_DISP_HOR_RES * 80];

// ============================================================
// ZUSTANDS-MANAGEMENT (STATE MACHINE)
// ============================================================
enum UiState {
    STATE_NAV_TARGET = 0,
    STATE_NAV_TURN = 1,
    STATE_NAV_SPEED = 2
};

UiState current_state = STATE_NAV_TURN; // Standardzustand beim Start

void set_ui_state(UiState state) {
    current_state = state;

    // 1. Zuerst ALLE zustandsspezifischen Objekte ausblenden
    lv_obj_add_flag(objects.nav_target, LV_OBJ_FLAG_HIDDEN);
    
    lv_obj_add_flag(objects.nav_turn, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(objects.distance, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(objects.distance_entity, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(objects.street, LV_OBJ_FLAG_HIDDEN);
    
    lv_obj_add_flag(objects.arc_speed, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(objects.lbl_speed, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(objects.lbl_speed_entity, LV_OBJ_FLAG_HIDDEN);

    // 2. Dann nur die Objekte des aktuellen Zustands einblenden
    // (bat_outline, battery, music, phone bleiben immer sichtbar und werden nicht angefasst)
    switch (state) {
        case STATE_NAV_TARGET:
            lv_obj_clear_flag(objects.nav_target, LV_OBJ_FLAG_HIDDEN);
            break;
            
        case STATE_NAV_TURN:
            lv_obj_clear_flag(objects.nav_turn, LV_OBJ_FLAG_HIDDEN);
            lv_obj_clear_flag(objects.distance, LV_OBJ_FLAG_HIDDEN);
            lv_obj_clear_flag(objects.distance_entity, LV_OBJ_FLAG_HIDDEN);
            lv_obj_clear_flag(objects.street, LV_OBJ_FLAG_HIDDEN);
            break;
            
        case STATE_NAV_SPEED:
            lv_obj_clear_flag(objects.arc_speed, LV_OBJ_FLAG_HIDDEN);
            lv_obj_clear_flag(objects.lbl_speed, LV_OBJ_FLAG_HIDDEN);
            lv_obj_clear_flag(objects.lbl_speed_entity, LV_OBJ_FLAG_HIDDEN);
            break;
    }
}

// ============================================================
// LVGL & DISPLAY SETUP
// ============================================================
void my_disp_flush(lv_display_t *disp, const lv_area_t *area, uint8_t *px_map) {
    uint32_t w = (area->x2 - area->x1 + 1);
    uint32_t h = (area->y2 - area->y1 + 1);

    // Höchste Geschwindigkeit mit Adafruit GFX
    tft.startWrite();
    tft.setAddrWindow(area->x1, area->y1, w, h);
    tft.writePixels((uint16_t *)px_map, w * h, true);
    tft.endWrite();

    lv_display_flush_ready(disp);
}

void boot_to_main_timer_cb(lv_timer_t * timer) {
    loadScreen(SCREEN_ID_MAIN); 
    
    // WICHTIG: Sobald Main geladen ist, den korrekten UI-Zustand herstellen
    set_ui_state(current_state);
    
    lv_timer_del(timer);
}

void setup() {
    Serial.begin(115200);
    Serial.println("NavGet Boot...");

    // 1. Display Initialisierung
    tft.begin();
    tft.setRotation(0);
    
    pinMode(TFT_BL, OUTPUT);
    digitalWrite(TFT_BL, HIGH);
    tft.fillScreen(0x0000); // Schwarz als Hintergrund gegen Flackern

    // 2. LVGL Initialisierung
    lv_init();

    lv_display_t *disp = lv_display_create(MY_DISP_HOR_RES, MY_DISP_VER_RES);
    lv_display_set_flush_cb(disp, my_disp_flush);
    lv_display_set_buffers(disp, buf, NULL, sizeof(buf), LV_DISPLAY_RENDER_MODE_PARTIAL);

    // 3. EEZ UI Screens im Speicher erstellen
    create_screens();

    // 4. Boot Screen laden
    loadScreen(SCREEN_ID_BOOT);

    // 5. Timer starten: Nach 3000ms (3 Sekunden) zu Main wechseln
    lv_timer_create(boot_to_main_timer_cb, 3000, NULL);

    Serial.println("NavGet Ready.");
    Serial.println("Zustände: 't'=Target, 'u'=Turn, 's'=Speed");
    Serial.println("Werte: 'n'=Naechstes, 'a'=Links, 'd'=Rechts, '+'/-'=Akku");
}

void loop() {
    // LVGL v9 Tick & Handler
    lv_tick_inc(5);
    lv_timer_handler();
    ui_tick(); 
    delay(5);

    handleSerialCommands();
}

// ============================================================
// SERIAL PARSER FÜR TESTS
// ============================================================
void handleSerialCommands() {
    if (Serial.available()) {
        char cmd = Serial.read();
        
        switch (cmd) {
            // --- ZUSTANDSWECHSEL ---
            case 't':
                Serial.println("Cmd: Zustand -> NavTarget");
                set_ui_state(STATE_NAV_TARGET);
                break;
            case 'u':
                Serial.println("Cmd: Zustand -> NavTurn");
                set_ui_state(STATE_NAV_TURN);
                break;
            case 's':
                Serial.println("Cmd: Zustand -> NavSpeed");
                set_ui_state(STATE_NAV_SPEED);
                break;

            // --- WERT-ÄNDERUNGEN (zum Testen der UI) ---
            case 'n': 
                Serial.println("Cmd: Naechstes Manoever (Distanz update)");
                lv_label_set_text(objects.distance, "150");
                break;
            case 'a': 
                Serial.println("Cmd: Zielrichtung links");
                // Hier könntest du später das Bild von objects.nav_target rotieren
                break;
            case 'd': 
                Serial.println("Cmd: Zielrichtung rechts");
                break;
            case '+': {
                Serial.println("Cmd: Akku +10%");
                int32_t batt = lv_bar_get_value(objects.battery);
                if (batt < 100) lv_bar_set_value(objects.battery, batt + 10, LV_ANIM_ON);
                break;
            }
            case '-': {
                Serial.println("Cmd: Akku -10%");
                int32_t batt = lv_bar_get_value(objects.battery);
                if (batt > 0) lv_bar_set_value(objects.battery, batt - 10, LV_ANIM_ON);
                break;
            }
            
            // --- TELEFON / MUSIK (Platzhalter für spätere Logik) ---
            case 'i': Serial.println("Cmd: Eingehender Anruf"); break;
            case 'x': Serial.println("Cmd: Aufgelegt"); break;
        }
    }
}